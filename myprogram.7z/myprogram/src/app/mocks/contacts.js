const { v4 } = require('uuid');
let contacts = [
  {
    id: v4(),
    name: 'Matheus',
    email: 'matheus@email.com',
    phone: '1199999999',
    category_id: v4()
  },
  {
    id: v4(),
    name: 'João',
    email: 'João@email.com',
    phone: '1199999999',
    category_id: v4()
  }
]

module.exports = contacts
